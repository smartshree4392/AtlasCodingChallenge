var fs = require("fs");
var readLineSync = require("readline-sync");

var fixObj = fs.readFileSync("fixtures.json", {endcoding:"UTF-8"});
var orgObj = fs.readFileSync("organizations.json", {endcoding:"UTF-8"});
var usersObj = fs.readFileSync("users.json", {endcoding:"UTF-8"});
var userOrgObj = fs.readFileSync("user_organizations.json", {endcoding:"UTF-8"});

var dataTree = require("data-tree");



var fixturesMainObj = JSON.parse(fixObj);
var orgMainObj = JSON.parse(orgObj);
var usersMainObj = JSON.parse(usersObj);
var userOrgMainObj = JSON.parse(userOrgObj);

async function getFixtureTreeForOrg(organizationId)
{

	var tree = dataTree.create();
	
	let fixtureMainObj = await fixturesMainObj[organizationId.toString()];
	
	let fixtureMainArr = await fixtureMainObj["fixtures"];
	
	let rootFixtureId = 0;
	
	let currOrganizationInfo = null;
	
	for(let j=0; j<orgMainObj.organizations.length; j++)
	{
		if(orgMainObj.organizations[j].organization_id == organizationId)
		{
			currOrganizationInfo = orgMainObj.organizations[j];
		}
	}
	
	//console.log(fixtureMainArr);
	
	for(let i=0; i<fixtureMainArr.length; i++)
	{
		if(fixtureMainArr[i].parent_id === null)
		{
			fixtureMainArr[i]["organization_info"] = await currOrganizationInfo;
			await tree.insert(fixtureMainArr[i]);
			rootFixtureId = await fixtureMainArr[i].fixture_id;
		}
		
	}
	
	for(let i=0; i<fixtureMainArr.length; i++)
	{
		if(fixtureMainArr[i].fixture_id !== rootFixtureId)
		{
			//console.log(fixtureMainArr[i]);
			
			fixtureMainArr[i]["organization_info"] = await currOrganizationInfo;
			
			tree.insertTo(function(data)
			{
					return data.fixture_id === fixtureMainArr[i].parent_id;
			}, fixtureMainArr[i]);
			
			//await tree.insertTo(targetNode, fixtureMainArr[i]);
		}
	}
	
	
	
	
	tree.traverser().traverseDFS(async function(node)
			{
				node._parentNode = node._data.parent_id;
				//console.log(node);
				
			});
			
		
	return await tree;
}



async function getFixtureTreeForUser(userName)
{
	
	var userFixturesTree = dataTree.create();
	
	let currentUserObj = null;
	let currentUserOrgArr = null;
	let fixtureTreeArr = new Array();
	
	for(let i=0; i<usersMainObj.users.length; i++)
	{
		if(usersMainObj.users[i].username === userName)
		{
			currentUserObj = await usersMainObj.users[i];
		}
	}
	
	for(let i=0; i<userOrgMainObj.user_orgs.length; i++)
	{
		if(userOrgMainObj.user_orgs[i].user_id === currentUserObj.user_id)
		{
			currentUserOrgArr = await userOrgMainObj.user_orgs[i].organizations;
		}
	}
	
	for(let j=0; j<currentUserOrgArr.length; j++)
	{
		await fixtureTreeArr.push(await getFixtureTreeForOrg(await currentUserOrgArr[j]));
		
		
	}
	
	for(let j=0; j<currentUserOrgArr.length; j++)
	{
		 fixtureTreeArr[j]._rootNode._parentNode = await currentUserObj.user_id;	
	}
	
	currentUserObj["organizations"] = await currentUserOrgArr;
	
	await userFixturesTree.insert(await currentUserObj);
	
	for(let k=0; k<fixtureTreeArr.length; k++)
	{
		await userFixturesTree._rootNode._childNodes.push(fixtureTreeArr[k]._rootNode);
		//console.log(fixtureTreeArr[k]);
	}
	//console.log(await userFixturesTree);
	return await userFixturesTree;
	
}




//getFixtureTreeForOrg(3);

//getFixtureTreeForUser("DummyCHOAdmin");


module.exports={getFixtureTreeForOrg, getFixtureTreeForUser};

