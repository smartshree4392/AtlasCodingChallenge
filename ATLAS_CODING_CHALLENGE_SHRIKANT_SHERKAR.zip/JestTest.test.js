var FixtureTree = require("./FixturesTree");


test("Function getFixtureTreeForUser should be defined.", () => {
	expect(FixtureTree.getFixtureTreeForUser).toBeDefined();
});



test("Function getFixtureTreeForOrg should be defined.", () => {
	expect(FixtureTree.getFixtureTreeForOrg).toBeDefined();
});

test("Function getFixtureTreeForUser should return tree.", () => {
	expect(typeof FixtureTree.getFixtureTreeForUser("OtherCHOAdmin")).toBe('object');
});

test("Function getFixtureTreeForOrg should return tree.", () => {
	expect(typeof FixtureTree.getFixtureTreeForOrg(1)).toBe('object');
});


test("Function getFixtureTreeForUser should return proper user information.", async () => {
	//await console.log(await FixtureTree.getFixtureTreeForUser("DummyCHOAdmin")._currentNode);
	
	let res = await FixtureTree.getFixtureTreeForUser("DummyCHOAdmin");
	
	//console.log(await res["_rootNode"]["_data"]);
	
	expect(await res["_rootNode"]["_data"]["username"]).toBe("DummyCHOAdmin");
});

test("Function getFixtureTreeForOrg should return proper organization information.", async () => {
	
	let res = await FixtureTree.getFixtureTreeForOrg(2);
	
	expect(await res._rootNode._data.fixture_id).toBe(11);
});
